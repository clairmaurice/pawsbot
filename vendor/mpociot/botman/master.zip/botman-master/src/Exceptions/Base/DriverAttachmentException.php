<?php

namespace BotMan\BotMan\Exceptions\Base;

class DriverAttachmentException extends DriverException
{
}
